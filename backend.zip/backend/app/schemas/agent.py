"""Structured NVIDIA model output schemas.

TODO:
- Define intents, extracted entities, missing fields, confidence, ambiguity, and requested tool calls.
- Reject unknown tools and unexpected update fields.
"""
# backend/app/schemas/agent.py

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):

    family_id: int

    user_id: Optional[int] = None

    message: str = Field(
        min_length=1,
        max_length=5000
    )

    conversation_id: Optional[int] = None


class ToolCall(BaseModel):

    name: str

    arguments: Dict[str, Any] = {}


class ChatResponse(BaseModel):

    message: str

    conversation_id: Optional[int] = None

    tool_calls: List[ToolCall] = []

    requires_clarification: bool = False

    metadata: Dict[str, Any] = {}