"""Nebius-hosted NVIDIA model client.

TODO:
- Implement one reusable client using environment-based configuration.
- Support structured responses and tool selection.
- Add timeouts, retries, error translation, and safe logging.
- Make the client replaceable with a test double.
"""
# backend/app/clients/ai_model.py

import os
from typing import Any, Dict, List, Optional

import httpx


class AIModelClient:
    """
    Common client for communicating with the configured AI model.

    The rest of the application should NOT directly call
    the NVIDIA/Nebius API. It should use this class.
    """

    def __init__(self):
        self.api_key = os.getenv("NVIDIA_API_KEY")
        self.base_url = os.getenv(
            "NVIDIA_API_URL",
            "https://integrate.api.nvidia.com/v1"
        )
        self.model = os.getenv(
            "NVIDIA_MODEL",
            "meta/llama-3.1-8b-instruct"
        )

    async def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.2,
        max_tokens: int = 1000,
    ) -> str:

        if not self.api_key:
            raise ValueError(
                "NVIDIA_API_KEY is not configured."
            )

        url = f"{self.base_url}/chat/completions"

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(
                url,
                headers=headers,
                json=payload,
            )

        response.raise_for_status()

        data = response.json()

        return data["choices"][0]["message"]["content"]