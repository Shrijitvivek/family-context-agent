"""Chat workflow service.

TODO:
- Persist messages, invoke the agent, execute validated actions, and build API responses.
- Preserve clarification context across turns.
- Never claim success until persistence succeeds.
"""
# backend/app/services/chat.py

from app.agents.orchestrator import FamilyContextAgent
from app.agents.state import AgentState


class ChatService:

    def __init__(
        self,
        agent: FamilyContextAgent,
    ):

        self.agent = agent

    async def process_message(
        self,
        family_id: int,
        user_id: int | None,
        message: str,
        conversation_id: int | None = None,
    ):

        state = AgentState(
            family_id=family_id,
            user_id=user_id,
            user_message=message,
            conversation_id=conversation_id,
        )

        state = await self.agent.run(state)

        return state