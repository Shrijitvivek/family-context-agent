"""Agent workflow state.

TODO:
- Define typed state for conversation context, extracted entities, candidates, and tool results.
- Represent clarification and document-confirmation states explicitly.
- Avoid treating model memory as persistent household state.
"""
# backend/app/agents/state.py

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class AgentState:

    family_id: Optional[int] = None

    user_id: Optional[int] = None

    user_message: str = ""

    conversation_id: Optional[int] = None

    assistant_message: str = ""

    tool_calls: List[Dict[str, Any]] = field(
        default_factory=list
    )

    tool_results: List[Dict[str, Any]] = field(
        default_factory=list
    )

    metadata: Dict[str, Any] = field(
        default_factory=dict
    )

    requires_clarification: bool = False

    clarification_question: Optional[str] = None