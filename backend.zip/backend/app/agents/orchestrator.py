"""Primary Family Context Agent orchestrator.

TODO:
- Gather relevant household and conversation context.
- Ask the NVIDIA model for structured intent and tool requests.
- Detect missing or ambiguous information before any state change.
- Validate and dispatch only registered tools.
- Record observable agent events without storing hidden chain-of-thought.
"""
from app.agents.prompts import (
    SYSTEM_PROMPT,
    build_user_prompt,
)

from app.agents.state import AgentState
from app.clients.ai_model import AIModelClient


class FamilyContextAgent:

    def __init__(
        self,
        ai_client: AIModelClient,
        tool_registry=None,
    ):

        self.ai_client = ai_client
        self.tool_registry = tool_registry

    async def run(
        self,
        state: AgentState,
    ) -> AgentState:

        messages = [
            {
                "role": "system",
                "content": SYSTEM_PROMPT,
            },
            {
                "role": "user",
                "content": build_user_prompt(
                    state.user_message
                ),
            },
        ]

        response = await self.ai_client.chat(
            messages=messages
        )

        state.assistant_message = response

        return state