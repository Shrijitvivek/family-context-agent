"""Agent event repository.

TODO:
- Persist observable agent and tool events for debugging and evaluation.
- Support request, conversation, entity, event-type, and time filters.
"""
# backend/app/repositories/agent_event.py

from typing import Any, Optional


class AgentEventRepository:

    def __init__(self, db):
        self.db = db

    async def create(
        self,
        family_id: int,
        event_type: str,
        event_data: Optional[dict[str, Any]] = None,
    ):

        # This repository is intentionally kept small.
        #
        # Connect this to your existing AgentEvent SQLAlchemy
        # model once your model fields are confirmed.

        event = {
            "family_id": family_id,
            "event_type": event_type,
            "event_data": event_data or {},
        }

        return event