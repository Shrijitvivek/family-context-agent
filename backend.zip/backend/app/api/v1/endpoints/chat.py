"""Chat and natural-language input endpoints.

TODO:
- Accept a family, optional member, message, and attachment references.
- Pass validated input to the chat service and agent orchestrator.
- Return responses, clarification prompts, confirmations, and UI actions.
"""
# backend/app/api/v1/endpoints/chat.py

from fastapi import APIRouter, Depends

from app.agents.orchestrator import FamilyContextAgent
from app.clients.ai_model import AIModelClient
from app.schemas.agent import (
    ChatRequest,
    ChatResponse,
)
from app.services.chat import ChatService


router = APIRouter(
    prefix="/chat",
    tags=["Chat"],
)


def get_chat_service() -> ChatService:

    ai_client = AIModelClient()

    agent = FamilyContextAgent(
        ai_client=ai_client
    )

    return ChatService(agent)


@router.post(
    "",
    response_model=ChatResponse
)
async def chat(
    request: ChatRequest,
):

    service = get_chat_service()

    state = await service.process_message(
        family_id=request.family_id,
        user_id=request.user_id,
        message=request.message,
        conversation_id=request.conversation_id,
    )

    return ChatResponse(
        message=state.assistant_message,
        conversation_id=state.conversation_id,
        tool_calls=[],
        requires_clarification=(
            state.requires_clarification
        ),
        metadata=state.metadata,
    )